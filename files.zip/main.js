/* ── SAI ENTERPRISES — main.js ── */

document.addEventListener('DOMContentLoaded', () => {

  /* ── NAVBAR SCROLL ── */
  const navbar = document.getElementById('navbar');
  const onScroll = () => {
    navbar?.classList.toggle('scrolled', window.scrollY > 40);
  };
  window.addEventListener('scroll', onScroll, { passive: true });
  onScroll();

  /* ── HAMBURGER MENU ── */
  const hamburger = document.querySelector('.hamburger');
  const mobileMenu = document.querySelector('.mobile-menu');
  hamburger?.addEventListener('click', () => {
    hamburger.classList.toggle('open');
    mobileMenu?.classList.toggle('open');
  });
  mobileMenu?.querySelectorAll('a').forEach(link => {
    link.addEventListener('click', () => {
      hamburger.classList.remove('open');
      mobileMenu.classList.remove('open');
    });
  });

  /* ── ACTIVE NAV LINK ── */
  const currentPage = location.pathname.split('/').pop() || 'index.html';
  document.querySelectorAll('.nav-links a, .mobile-menu a').forEach(a => {
    const href = a.getAttribute('href');
    if (href === currentPage || (currentPage === '' && href === 'index.html')) {
      a.classList.add('active');
    }
  });

  /* ── FADE-UP OBSERVER ── */
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(e => {
      if (e.isIntersecting) {
        e.target.classList.add('visible');
        observer.unobserve(e.target);
      }
    });
  }, { threshold: 0.12 });
  document.querySelectorAll('.fade-up').forEach(el => observer.observe(el));

  /* ── GALLERY FILTER ── */
  const filterBtns = document.querySelectorAll('.filter-btn');
  const galleryItems = document.querySelectorAll('.gallery-item');
  filterBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      filterBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const cat = btn.dataset.filter;
      galleryItems.forEach(item => {
        const show = cat === 'all' || item.dataset.cat === cat;
        item.style.display = show ? '' : 'none';
        item.style.opacity = show ? '1' : '0';
      });
    });
  });

  /* ── CONTACT FORM ── */
  const contactForm = document.getElementById('contactForm');
  contactForm?.addEventListener('submit', (e) => {
    e.preventDefault();
    const btn = contactForm.querySelector('[type="submit"]');
    const orig = btn.innerHTML;
    btn.innerHTML = '✔ Message Sent!';
    btn.disabled = true;
    btn.style.background = '#16a34a';
    setTimeout(() => {
      btn.innerHTML = orig;
      btn.disabled = false;
      btn.style.background = '';
      contactForm.reset();
    }, 3500);
  });

});

/* ── QUOTATION CALCULATOR ── */
const MATERIALS = {
  'MS':  { label: 'Mild Steel (MS)',        ratePerSqFt: 65,  ratePerKg: 55,  density: 7.85 },
  'SS':  { label: 'Stainless Steel (SS)',   ratePerSqFt: 180, ratePerKg: 165, density: 8.0  },
  'AL':  { label: 'Aluminum',               ratePerSqFt: 145, ratePerKg: 140, density: 2.70 },
  'GI':  { label: 'Galvanized Iron (GI)',   ratePerSqFt: 85,  ratePerKg: 72,  density: 7.85 },
};

const THICKNESS_MM = [1.2, 1.6, 2.0, 2.5, 3.0, 4.0, 5.0, 6.0, 8.0, 10.0];

const SERVICES_EXTRA = {
  'cutting':   { label: 'Cutting & Shearing',  pct: 0    },
  'welding':   { label: '+ Welding',            pct: 0.20 },
  'polishing': { label: '+ Polishing / Finish', pct: 0.30 },
  'painting':  { label: '+ Painting',           pct: 0.18 },
};

function formatINR(n) {
  return '₹' + Math.round(n).toLocaleString('en-IN');
}

function runCalc() {
  const matKey   = document.getElementById('calcMaterial')?.value;
  const thickMM  = parseFloat(document.getElementById('calcThickness')?.value || 3);
  const length   = parseFloat(document.getElementById('calcLength')?.value   || 0);
  const width    = parseFloat(document.getElementById('calcWidth')?.value    || 0);
  const qty      = parseInt(document.getElementById('calcQty')?.value        || 1, 10);
  const svcKey   = document.getElementById('calcService')?.value || 'cutting';
  const pricingMode = document.getElementById('pricingMode')?.value || 'sqft';

  const mat = MATERIALS[matKey];
  if (!mat || !length || !width) {
    updateDisplay(null); return;
  }

  const areaSqFt   = (length * width) / 144;         // inches → sq ft
  const thickIn    = thickMM / 25.4;
  const volCuIn    = length * width * thickIn;
  const weightKg   = (volCuIn * 0.0000163871) * mat.density * 1000; // cu-in → m³ → kg

  let basePrice;
  if (pricingMode === 'sqft') {
    basePrice = areaSqFt * mat.ratePerSqFt;
  } else {
    basePrice = weightKg * mat.ratePerKg;
  }

  const svc        = SERVICES_EXTRA[svcKey];
  const svcCost    = basePrice * svc.pct;
  const unitPrice  = basePrice + svcCost;
  const total      = unitPrice * qty;
  const gst        = total * 0.18;
  const grandTotal = total + gst;

  updateDisplay({
    mat, thickMM, areaSqFt, weightKg, qty,
    basePrice, svcCost, svc,
    unitPrice, total, gst, grandTotal,
    pricingMode
  });
}

function updateDisplay(d) {
  const priceEl = document.getElementById('priceAmount');
  const breakdownEl = document.getElementById('priceBreakdown');
  if (!priceEl || !breakdownEl) return;

  if (!d) {
    priceEl.textContent = '₹0';
    breakdownEl.innerHTML = '<p style="color:var(--text-dim);font-size:.85rem;text-align:center;padding:1rem 0;">Enter dimensions to calculate</p>';
    return;
  }

  priceEl.textContent = formatINR(d.grandTotal);

  breakdownEl.innerHTML = `
    <div class="price-row">
      <span class="price-row-label">Material</span>
      <span class="price-row-value">${d.mat.label}</span>
    </div>
    <div class="price-row">
      <span class="price-row-label">Thickness</span>
      <span class="price-row-value">${d.thickMM} mm</span>
    </div>
    <div class="price-row">
      <span class="price-row-label">Area</span>
      <span class="price-row-value">${d.areaSqFt.toFixed(2)} sq.ft</span>
    </div>
    <div class="price-row">
      <span class="price-row-label">Approx. Weight</span>
      <span class="price-row-value">${d.weightKg.toFixed(2)} kg</span>
    </div>
    <div class="price-row">
      <span class="price-row-label">Base (${d.pricingMode === 'sqft' ? 'Area' : 'Weight'})</span>
      <span class="price-row-value">${formatINR(d.basePrice)}</span>
    </div>
    ${d.svc.pct > 0 ? `<div class="price-row">
      <span class="price-row-label">${d.svc.label}</span>
      <span class="price-row-value">+${formatINR(d.svcCost)}</span>
    </div>` : ''}
    <div class="price-row">
      <span class="price-row-label">Unit Price</span>
      <span class="price-row-value">${formatINR(d.unitPrice)}</span>
    </div>
    <div class="price-row">
      <span class="price-row-label">Quantity</span>
      <span class="price-row-value">× ${d.qty}</span>
    </div>
    <div class="price-row">
      <span class="price-row-label">Subtotal</span>
      <span class="price-row-value">${formatINR(d.total)}</span>
    </div>
    <div class="price-row">
      <span class="price-row-label">GST (18%)</span>
      <span class="price-row-value">+${formatINR(d.gst)}</span>
    </div>
    <div class="price-row total">
      <span class="price-row-label">Grand Total</span>
      <span class="price-row-value">${formatINR(d.grandTotal)}</span>
    </div>
  `;
}

// Expose to inline usage
window.runCalc = runCalc;
